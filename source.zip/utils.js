export const range = (f) => [...Array(f).keys()];
